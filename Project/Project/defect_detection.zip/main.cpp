#include "defect_detection.hpp"

void visualize(vector<double>& D, Mesh& M_d);

int main()    
{
    // defect detection
    Mesh M_o = read_mesh(R"(C:\_Research\_result\mesh\C.off)");
    Mesh M_d = read_mesh(R"(C:\_Research\_result\mesh\C_modified.off)");
    int delta = 30;
    double alpha = 1.0;
    double beta = 0.8;
    vector<double> D = defect_detection(M_o, M_d, delta, alpha, beta);

    // compute error
    double vertex_mean_error = compute_vertex_mean_error(D);
    double weighted_mean_error = compute_weighted_mean_error(M_d, D);
    double maximum_error = compute_maximum_error(D);

    cout << endl << "- Error ----------" << endl;
    cout << "vertex mean error : " << vertex_mean_error << endl;
    cout << "weighted mean error : " << weighted_mean_error << endl;
    cout << "maximum error : " << maximum_error << endl;

    cout << fixed;
    cout.precision(2);
    for (double d : vector<double>{ .4, .5, .6, .7, .8, .9 })
        cout << "percentages of vertices with error at most " << d << " : " << compute_percentages_with_error(D, d) << endl;

    // visualization
    // visualize(D, M_d);
    // write_mesh(M_d, (R"(C:\_Research\_result\mesh\A_result.off)"));

    return 0;
}

void visualize(vector<double>& D, Mesh& M_d)
{
    auto face_color_map = M_d.add_property_map<Mesh::Face_index, Color>("f:color", Color(255, 255, 255)).first;
    double maximum_error = compute_maximum_error(D);

    for (auto face : M_d.faces())
    {
        int c = 0;
        double x = 0;
        double angle = 0;

        for (auto vertex : CGAL::vertices_around_face(M_d.halfedge(face), M_d))
        {
            c++;
            x += D[vertex.idx()];
        }
        x /= c * maximum_error;

        if (x <= 0.3)
            face_color_map[face] = Color(255, 255, 255);
        else if (x <= 0.4)
            face_color_map[face] = Color(255, 255, 0);
        else if (x <= 0.5)
            face_color_map[face] = Color(127, 255, 255);
        else if (x <= 0.6)
            face_color_map[face] = Color(0, 255, 0);
        else if (x <= 0.7)
            face_color_map[face] = Color(0, 127, 127);
        else if (x <= 0.8)
            face_color_map[face] = Color(0, 0, 255);
        else if (x <= 0.9)
            face_color_map[face] = Color(0, 0, 127);
        else
            face_color_map[face] = Color(0, 0, 0);
    }
}