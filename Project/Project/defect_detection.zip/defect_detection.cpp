﻿#include "defect_detection.hpp"

Mesh read_mesh(const char* path)
{
    Mesh mesh;
    ifstream input(path);
    input >> mesh;

    return mesh;
}

void write_mesh(Mesh mesh, const char* path)
{
    ofstream output(path);
    output << mesh;
}

bool is_segment_inside(Tree& tree, Inside_tester& inside_tester, Segment& segment)
{
    return !tree.do_intersect(segment) && inside_tester(segment.source()) == CGAL::ON_BOUNDED_SIDE && inside_tester(segment.target()) == CGAL::ON_BOUNDED_SIDE;
}

void laplacian_smoothing(Skeleton& S, int iter, double lambda)
{
    cout << "laplacin_smoothing()" << endl;

    vector<set<int>> edges(S.V.size());
    for (const auto& edge : S.E)
    {
        edges[edge.first].insert(edge.second);
        edges[edge.second].insert(edge.first);
    }

    for (int i = 0; i < iter; i++)
    {
        vector<Point> vertices2 = S.V;
        for (int u = 0; u < S.V.size(); u++)
        {
            if (edges[u].size() == 0)
                continue;

            Vector dir = Vector(0, 0, 0);
            for (int v : edges[u])
                dir += S.V[v] - Point(0, 0, 0);
            dir = (dir / edges[u].size()) - (S.V[u] - Point(0, 0, 0));
            vertices2[u] += dir * lambda;
        }
        S.V = vertices2;
    }
}

Skeleton medial_skeleton(Mesh& M)
{
    cout << "medial_skeleton()" << endl;

    Skeleton S;
    Delaunay dt;
    map<Delaunay::Vertex_handle, int> t_handles;

    Tree tree(M.faces().first, M.faces().second, M);
    Inside_tester inside_tester(M);
    tree.accelerate_distance_queries();
    dt.insert(M.points().begin(), M.points().end());

    for (auto it = dt.finite_edges_begin(); it != dt.finite_edges_end(); it++)
    {
        try
        {
            Delaunay::Cell_handle cell = it->first;
            int i = it->second, j = it->third;
            Delaunay::Cell_handle neighbor = cell->neighbor(j);

            if (!dt.is_infinite(cell) && !dt.is_infinite(neighbor))
            {
                Point p1 = dt.dual(cell);
                Point p2 = dt.dual(neighbor);
                Segment segment(p1, p2);

                if (is_segment_inside(tree, inside_tester, segment))
                {
                    Delaunay::Vertex_handle v1 = cell->vertex(i);
                    Delaunay::Vertex_handle v2 = cell->vertex(j);

                    if (t_handles.find(v1) == t_handles.end())
                        t_handles.insert({ v1, t_handles.size() }), S.V.push_back(p1);
                    if (t_handles.find(v2) == t_handles.end())
                        t_handles.insert({ v2, t_handles.size() }), S.V.push_back(p2);

                    int v1i = t_handles[v1];
                    int v2i = t_handles[v2];
                    S.E.push_back({ v1i, v2i });
                }
            }
        }
        catch (exception)
        {
        }
    }

    laplacian_smoothing(S, 100, 1.0);
    return S;
}

MRH construct_MRH(Skeleton& S)
{
    cout << "construct_MRH()" << endl;

    MRH T;

    vector<bool> isMerged;
    vector<set<int>> edges;
    priority_queue<tuple<float, int, int>> pq;
    set<int> curr;

    for (int i = 0; i < S.V.size(); i++)
    {
        T.P.push_back(S.V[i]);
        isMerged.push_back(false);
        edges.push_back(set<int>());
        curr.insert(i);
    }

    for (int i = 0; i < S.E.size(); i++)
    {
        pq.push({ -CGAL::squared_distance(T.P[S.E[i].first], T.P[S.E[i].second]), S.E[i].first, S.E[i].second });
        edges[S.E[i].first].insert(S.E[i].second);
        edges[S.E[i].second].insert(S.E[i].first);
    }

    int t = 0;
    while (!pq.empty())
    {
        auto top = pq.top();
        pq.pop();

        int i = get<1>(top);
        int j = get<2>(top);
        if (isMerged[i] || isMerged[j])
            continue;

        int u = T.P.size();
        T.H.push_back({ i, j, u });

        Point pos = Point((T.P[i].x() + T.P[j].x()) * 0.5f, (T.P[i].y() + T.P[j].y()) * 0.5f, (T.P[i].z() + T.P[j].z()) * 0.5f);
        isMerged[i] = isMerged[j] = true;
        T.P.push_back(pos);
        isMerged.push_back(false);
        edges.push_back(set<int>());

        if (t % 4000 == 3999)
        {
            vector<tuple<float, int, int>> vec;
            while (!pq.empty())
            {
                auto top = pq.top();
                pq.pop();
                if (isMerged[get<1>(top)] || isMerged[get<2>(top)])
                    continue;
                vec.push_back(top);
            }
            for (const auto& x : vec)
                pq.push(x);
        }

        for (int v : edges[i])
        {
            if (isMerged[v])
                continue;

            edges[u].insert(v);
            edges[v].insert(u);
            edges[v].erase(i);
            edges[v].erase(j);
            pq.push({ -CGAL::squared_distance(T.P[u], T.P[v]), u, v });
        }

        for (int v : edges[j])
        {
            if (isMerged[v])
                continue;

            edges[u].insert(v);
            edges[v].insert(u);
            edges[v].erase(i);
            edges[v].erase(j);
            pq.push({ -CGAL::squared_distance(T.P[u], T.P[v]), u, v });
        }

        edges[i].clear();
        edges[j].clear();
        edges[u].erase(i);
        edges[u].erase(j);

        curr.erase(i);
        curr.erase(j);
        curr.insert(u);
    }

    return T;
}

void adjust_skeleton(MRH& T, vector<Point>& V_o, vector<Point>& V_d, int offset, double alpha, double beta)
{
    cout << "adjust_skeleton()" << endl;

    AABBTree aabb(V_o.begin(), V_o.end());

    set<int> visited;
    set<int> curVertices;
    vector<Vector> diffSum(T.P.size());

    for (int i = 0; i < diffSum.size(); i++)
        diffSum[i] = Vector(0, 0, 0);

    int cur = 0;
    for (int t = T.H.size() - 1; t >= 0; t--)
    {
        auto tuple = T.H[t];
        int i = get<0>(tuple);
        int j = get<1>(tuple);
        int u = get<2>(tuple);

        Vector alphaVec = diffSum[u] * alpha;
        bool asdf = false;
        if (cur < offset)
        {
            if (visited.find(u) == visited.end())
                cur++;
            else
                curVertices.erase(u);
            cur += 2;
            visited.insert(i);
            visited.insert(j);
            visited.insert(u);
            curVertices.insert(i);
            curVertices.insert(j);

            T.P[i] += alphaVec;
            T.P[j] += alphaVec;
            diffSum[i] += alphaVec;
            diffSum[j] += alphaVec;

            vector<pair<Point, int>> vec;
            map<int, int> vertCnt;
            map<int, Vector> vertVec;
            for (int p : curVertices)
            {
                vec.push_back({ T.P[p], p });
                vertCnt.insert({ p, 0 });
                vertVec.insert({ p, Vector(0, 0, 0) });
            }
            AABBTree2 aabb2(vec.begin(), vec.end());

            for (int w = 0; w < 1; w++)
            {
                for (int p : curVertices)
                {
                    vertCnt[p] = 0;
                    vertVec[p] = Vector(0, 0, 0);
                }
                for (int v = 0; v < V_o.size(); v++)
                {
                    Point_with_index closet = Neighbor_search2(aabb2, V_o[v]).begin()->first;
                    vertVec[closet.second] += V_o[v] - Point(0, 0, 0);
                    vertCnt[closet.second]++;
                }
                for (int p : curVertices)
                {
                    if (vertCnt[p] != 0)
                    {
                        Vector to = vertVec[p] / (double)vertCnt[p];
                        Vector diffVec = Point(0, 0, 0) + to - T.P[p];

                        Vector betaVec = diffVec * beta;
                        diffSum[p] += betaVec;
                        T.P[p] += betaVec;
                    }
                }
            }
        }
        else
        {
            if (visited.find(u) == visited.end())
            {
                cur++;
                Point closet = Neighbor_search(aabb, T.P[u]).begin()->first;
                Vector diffVec = closet - T.P[u];
                diffSum[u] += diffVec;
                T.P[u] += diffVec;
            }

            cur += 2;
            visited.insert(i);
            visited.insert(j);
            visited.insert(u);

            T.P[i] += alphaVec;
            T.P[j] += alphaVec;
            Point close_i = Neighbor_search(aabb, T.P[i]).begin()->first;
            Point close_j = Neighbor_search(aabb, T.P[j]).begin()->first;
            Vector diffVec_i = close_i - T.P[i];
            Vector diffVec_j = close_j - T.P[j];
            diffSum[i] += alphaVec + diffVec_i;
            diffSum[j] += alphaVec + diffVec_j;
            T.P[i] += diffVec_i;
            T.P[j] += diffVec_j;
        }
    }

    for (int t = 0; t < V_d.size(); t++)
        V_d[t] += diffSum[t];
}

vector<double> calculate_defect(Mesh& M_o, Mesh& M_d, vector<Point>& V_d, vector<Point>& V_d_clone)
{
    cout << "calculate_defect()" << endl;

    vector<double> D;

    vector<pair<Point, int>> vert1;
    for (int i = 0; i < V_d_clone.size(); i++)
        vert1.push_back({ V_d_clone[i], i });
    AABBTree2 aabb1(vert1.begin(), vert1.end());

    vector<pair<Point, int>> vert2;
    for (int i = 0; i < M_o.number_of_vertices(); i++)
        vert2.push_back({ M_o.point(Mesh::Vertex_index(i)) , i });
    AABBTree2 aabb2(vert2.begin(), vert2.end());

    for (auto vertex : M_d.vertices())
    {
        Neighbor_search2 search(aabb1, M_d.point(vertex));
        auto closet = search.begin()->first;
        int i = closet.second;

        Neighbor_search2 search2(aabb2, M_d.point(vertex) + (V_d[i] - V_d_clone[i]));
        auto closet2 = search2.begin()->first;
        D.push_back(sqrt((closet2.first - M_d.point(vertex)).squared_length()));
    }

    return D;
}

vector<double> defect_detection(Mesh& M_o, Mesh& M_d, int delta, double alpha, double beta)
{
    Skeleton S_o = medial_skeleton(M_o);
    Skeleton S_d = medial_skeleton(M_d);
    vector<Point> V_d_clone = S_d.V;
    MRH T = construct_MRH(S_d);
    adjust_skeleton(T, S_o.V, S_d.V, delta, alpha, beta);
    vector<double> D = calculate_defect(M_o, M_d, S_d.V, V_d_clone);
    return D;
}

double compute_vertex_mean_error(vector<double>& D)
{
    double error = 0;
    for (double e : D)
        error += e;
    return error /= D.size();
}

double compute_weighted_mean_error(Mesh& M_d, vector<double>& D)
{
    std::vector<double> vertex_areas(M_d.num_vertices(), 0.0);
    double area = 0.0;

    for (const auto& face : M_d.faces())
    {
        std::vector<Mesh::Vertex_index> vertices;
        for (const auto& vertex : CGAL::vertices_around_face(M_d.halfedge(face), M_d))
            vertices.push_back(vertex);

        Point p0 = M_d.point(vertices[0]);
        for (int i = 1; vertices.size() > i + 1; i++) {
            Point p1 = M_d.point(vertices[i]);
            Point p2 = M_d.point(vertices[i + 1]);

            double tri_area = 0.5 * CGAL::sqrt(CGAL::squared_area(p0, p1, p2));
            area += tri_area;

            vertex_areas[vertices[0]] += tri_area / 3.0;
            vertex_areas[vertices[i]] += tri_area / 3.0;
            vertex_areas[vertices[i + 1]] += tri_area / 3.0;
        }
    }

    double error = 0.0;
    for (size_t i = 0; i < D.size(); i++)
        error += D[i] * vertex_areas[i];

    return error / area;
}

double compute_maximum_error(vector<double>& D)
{
    double error = D[0];
    for (double e : D)
        error = max(e, error);
    return error;
}

double compute_percentages_with_error(vector<double>& D, double d)
{
    int cnt = 0;
    for (double e : D)
        if (e <= d)
            cnt++;
    return (double)cnt / D.size() * 100.0;
}